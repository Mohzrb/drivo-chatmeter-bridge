
# Drivo ↔ Chatmeter ↔ Zendesk Bridge (Vercel)

Two endpoints:
- `POST /api/review-webhook` → Creates a Zendesk ticket from a Chatmeter review payload.
- `POST /api/zendesk-reply` → Sends the first public reply from Zendesk back to Chatmeter.

## Env Vars (Vercel → Settings → Environment Variables)

ZENDESK_SUBDOMAIN=drivohelp
ZENDESK_EMAIL=mohamed@drivo.com
ZENDESK_API_TOKEN=********

CHATMETER_V5_BASE=https://live.chatmeter.com/v5
CHATMETER_V5_TOKEN=********   # your PowerShell-generated token

# Optional (custom field IDs in Zendesk)
ZD_FIELD_REVIEW_ID=1234567890
ZD_FIELD_LOCATION_ID=1234567891
ZD_FIELD_RATING=1234567892
ZD_FIELD_FIRST_REPLY_SENT=1234567893

## Deploy
1. Push this repo to GitHub.
2. Import in Vercel → select your repo → deploy.
3. After deploy, copy the URLs:
   - https://<your-app>.vercel.app/api/review-webhook
   - https://<your-app>.vercel.app/api/zendesk-reply

## Wire it up

### A) Chatmeter → review-webhook
Ask Chatmeter CSM to POST review payloads to your `/api/review-webhook` URL.

Example payload accepted:
```json
{
  "id": "rvw_123",
  "locationId": "loc_45",
  "locationName": "JFK",
  "rating": 2,
  "authorName": "John D",
  "createdAt": "2025-10-06T03:20:00Z",
  "text": "Long wait time.",
  "publicUrl": "https://example.com/review/rvw_123",
  "portalUrl": "https://live.chatmeter.com/review/rvw_123"
}
```

### B) Zendesk → zendesk-reply
Create a Zendesk Trigger:
- **All conditions**
  - Ticket → Is → Updated
  - Comment → Is → Public
  - Tags → Contains at least one of → `chatmeter_first_reply_pending`
  - (Optional) Custom field "First Reply Sent?" → Is → `false`
- **Actions**
  - **Notify active webhook** (create a Zendesk webhook pointing to your `/api/zendesk-reply`)
  - JSON Body:
```json
{
  "ticket_id": "{{ticket.id}}",
  "review_id": "{{ticket.ticket_field_<REVIEW_ID_FIELDID>}}",
  "reply_text": "{{ticket.latest_public_comment}}",
  "agent": "{{current_user.name}}"
}
```
  - Add/Remove tags as you prefer.

## cURL tests

### 1) Simulate Chatmeter → create ticket
```bash
curl -X POST "https://<your-app>.vercel.app/api/review-webhook"   -H "Content-Type: application/json"   -d '{
    "id":"rvw_123",
    "locationId":"loc_45",
    "locationName":"JFK",
    "rating":2,
    "authorName":"John D",
    "createdAt":"2025-10-06T03:20:00Z",
    "text":"Long wait time but staff was helpful.",
    "publicUrl":"https://example.com/review/rvw_123",
    "portalUrl":"https://live.chatmeter.com/review/rvw_123"
  }'
```

### 2) Simulate Zendesk → Chatmeter reply
```bash
curl -X POST "https://<your-app>.vercel.app/api/zendesk-reply"   -H "Content-Type: application/json"   -d '{
    "ticket_id": 123456,
    "review_id": "rvw_123",
    "reply_text": "Thank you for your feedback. We are reviewing your case."
  }'
```
