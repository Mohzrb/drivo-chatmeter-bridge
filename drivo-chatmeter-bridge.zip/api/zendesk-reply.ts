// Zendesk → Chatmeter (post the FIRST public reply), then mark ticket in Zendesk
// Deployed as: POST https://<your-app>.vercel.app/api/zendesk-reply

const CHM_BASE = process.env.CHATMETER_V5_BASE || "https://live.chatmeter.com/v5";
const CHM_TOKEN = process.env.CHATMETER_V5_TOKEN;
const ZD_SUBDOMAIN = process.env.ZENDESK_SUBDOMAIN;
const ZD_EMAIL = process.env.ZENDESK_EMAIL;
const ZD_API_TOKEN = process.env.ZENDESK_API_TOKEN;
const ZD_FIELD_FIRST_REPLY_SENT = process.env.ZD_FIELD_FIRST_REPLY_SENT; // number as string

function badEnv() {
  const missing = [
    !CHM_TOKEN && "CHATMETER_V5_TOKEN",
    !ZD_SUBDOMAIN && "ZENDESK_SUBDOMAIN",
    !ZD_EMAIL && "ZENDESK_EMAIL",
    !ZD_API_TOKEN && "ZENDESK_API_TOKEN",
  ].filter(Boolean);
  return missing.length ? `Missing env: ${missing.join(", ")}` : null;
}

export default async function handler(req: any, res: any) {
  try {
    if (req.method !== "POST") { res.status(405).send("Method Not Allowed"); return; }
    const envErr = badEnv();
    if (envErr) { res.status(500).send(envErr); return; }

    const body = typeof req.body === "string" ? JSON.parse(req.body) : (req.body || {});
    const ticket_id = body.ticket_id;
    const review_id = body.review_id;
    const reply_text = body.reply_text;

    if (!ticket_id || !review_id || !reply_text) {
      res.status(400).send("Missing ticket_id/review_id/reply_text");
      return;
    }

    // 1) Post reply to Chatmeter
    const chmRes = await fetch(`${CHM_BASE}/reviews/${encodeURIComponent(review_id)}/responses`, {
      method: "POST",
      headers: {
        "Authorization": `Bearer ${CHM_TOKEN}`,
        "Content-Type": "application/json"
      },
      body: JSON.stringify({ detail: reply_text })
    });

    if (!chmRes.ok) {
      const t = await chmRes.text();
      res.status(502).send(`Chatmeter error: ${chmRes.status} ${t}`);
      return;
    }

    // 2) Mark "First Reply Sent" in Zendesk (optional if field configured)
    if (ZD_FIELD_FIRST_REPLY_SENT) {
      const update = {
        ticket: {
          id: ticket_id,
          custom_fields: [{ id: +ZD_FIELD_FIRST_REPLY_SENT, value: true }],
          tags: ["chatmeter_first_reply_sent"]
        }
      };

      const auth = Buffer.from(`${ZD_EMAIL}/token:${ZD_API_TOKEN}`).toString("base64");
      const zdRes = await fetch(`https://${ZD_SUBDOMAIN}.zendesk.com/api/v2/tickets/${ticket_id}.json`, {
        method: "PUT",
        headers: {
          "Content-Type": "application/json",
          "Authorization": "Basic " + auth
        },
        body: JSON.stringify(update)
      });

      if (!zdRes.ok) {
        const et = await zdRes.text();
        res.status(207).send(`Reply sent but Zendesk update failed: ${zdRes.status} ${et}`);
        return;
      }
    }

    res.status(200).json({ ok: true });
  } catch (e: any) {
    res.status(500).send(`Error: ${e?.message || e}`);
  }
}
